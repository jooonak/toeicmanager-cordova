import {
    Component
}
from "@angular/core";

@
Component({
    moduleId: module.id,
    selector: "ns-main",
    templateUrl: "app.component.html"
})
export class AppComponent {}