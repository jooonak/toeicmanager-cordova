export enum NavigationModes {
  NONE,
  LISTMENU,
  DRAWER,
  TABSTRIP
}
