export * from "./platform.directive";
export * from "./hyperlink.directive";
/// placeholder for other directives
