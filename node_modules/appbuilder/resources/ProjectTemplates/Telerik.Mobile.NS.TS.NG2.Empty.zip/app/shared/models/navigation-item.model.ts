export interface NavigationItem {
  path: string;
  title: string;
  icon: string;
}
