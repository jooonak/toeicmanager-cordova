"use strict";
//# sourceMappingURL=navigation-item.model.js.map