"use strict";
/// modules imports
var homeView_component_1 = require("../../modules/homeView/homeView.component");
exports.ROUTES = [
    /// start routes declaration
    { path: "homeView", component: homeView_component_1.HomeViewComponent },
    {
        path: "",
        component: homeView_component_1.HomeViewComponent
    }
];
//# sourceMappingURL=routes.constant.js.map