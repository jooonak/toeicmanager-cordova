"use strict";
/// modules imports
var homeView_module_1 = require("../../modules/homeView/homeView.module");
exports.MODULES = [
    /// start modules declaration
    homeView_module_1.HomeViewModule
];
//# sourceMappingURL=modules.constant.js.map