/// modules imports
import { HomeViewModule } from "../../modules/homeView/homeView.module";

export const MODULES = [
/// start modules declaration
HomeViewModule
/// end modules declaration
];
