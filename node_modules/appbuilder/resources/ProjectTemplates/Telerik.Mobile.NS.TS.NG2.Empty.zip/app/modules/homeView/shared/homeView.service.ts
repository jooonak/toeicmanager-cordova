import {
    Injectable
}
from "@angular/core";
/// service imports
import * as shared from "../../../shared";

@
Injectable()
export class HomeViewService {
    /// service class
}