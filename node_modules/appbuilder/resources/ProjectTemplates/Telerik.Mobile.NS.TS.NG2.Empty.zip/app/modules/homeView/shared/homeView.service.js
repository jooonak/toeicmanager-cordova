"use strict";
var core_1 = require("@angular/core");
var HomeViewService = (function () {
    function HomeViewService() {
    }
    HomeViewService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], HomeViewService);
    return HomeViewService;
}());
exports.HomeViewService = HomeViewService;
//# sourceMappingURL=homeView.service.js.map