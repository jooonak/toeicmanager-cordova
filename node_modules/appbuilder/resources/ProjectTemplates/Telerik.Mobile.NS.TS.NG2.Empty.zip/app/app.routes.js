"use strict";
exports.appRoutes = [
    {
        path: "",
        redirectTo: "/nav",
        pathMatch: "full"
    }
];
//# sourceMappingURL=app.routes.js.map