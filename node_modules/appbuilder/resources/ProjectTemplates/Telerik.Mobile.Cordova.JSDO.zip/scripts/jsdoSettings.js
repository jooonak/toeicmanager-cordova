var jsdoSettings = { 

      "serviceURI": "<enter data service uri here>",
      "catalogURIs": "<enter data service catalog uris here>",
      "authenticationModel": "<enter the authentication model>",
      "displayFields": "<fields to display from table>",
      "resourceName": "<resource name in catalog>"
      // TO_DO
      //, "tableName": "<tablename if multi-table resource>"
};
