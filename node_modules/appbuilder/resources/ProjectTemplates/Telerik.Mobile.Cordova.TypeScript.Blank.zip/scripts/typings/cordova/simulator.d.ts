interface Navigator {
	simulator?: boolean;
}