import { Component } from "@angular/core";

@Component({
  selector: "ns-main",
  template: "<page-router-outlet></page-router-outlet>"
})
export class AppComponent {}
