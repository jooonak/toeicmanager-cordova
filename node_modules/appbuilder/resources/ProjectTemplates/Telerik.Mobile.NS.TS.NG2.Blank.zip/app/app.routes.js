"use strict";
exports.appRoutes = [
    {
        path: "",
        redirectTo: "/home",
        pathMatch: "full"
    }
];
//# sourceMappingURL=app.routes.js.map