"use strict";
var router_1 = require("@angular/router");
var home_component_1 = require("./home.component");
var homeRoutes = [
    {
        path: 'home',
        component: home_component_1.HomeComponent
    }
];
exports.homeRouting = router_1.RouterModule.forChild(homeRoutes);
//# sourceMappingURL=home.routes.js.map